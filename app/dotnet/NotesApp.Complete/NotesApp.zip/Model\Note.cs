﻿namespace NotesApp.Complete.Model
{
    public class Note
    {
        public string Id { get; set; }

        public string Username { get; set; }

        public string Content { get; set; }
    }
}